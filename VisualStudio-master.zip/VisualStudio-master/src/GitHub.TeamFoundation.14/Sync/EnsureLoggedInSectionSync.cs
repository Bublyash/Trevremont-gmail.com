using System.ComponentModel.Composition;
using GitHub.Api;
using GitHub.Models;
using GitHub.Services;
using Microsoft.TeamFoundation.Controls;

namespace GitHub.VisualStudio.TeamExplorer.Sync
{
    // TODO: The IsAGitHubRepo() is somehow giving false positives, need to fix that
    // before reactivating this, it's annoying users.
    //[TeamExplorerSection(SyncLoginSectionId, TeamExplorerPageIds.GitCommits, 10)]
    //[PartCreationPolicy(CreationPolicy.NonShared)]
    public class EnsureLoggedInSectionSync : EnsureLoggedInSection
    {
        public const string SyncLoginSectionId = "C5975729-3CF1-47B4-AE92-C2934906CDDA";

        [ImportingConstructor]
        public EnsureLoggedInSectionSync(ISimpleApiClientFactory apiFactory, ITeamExplorerServiceHolder holder,
            IConnectionManager cm, IRepositoryHosts hosts, ITeamExplorerServices teServices)
            : base(apiFactory, holder, cm, hosts, teServices)
        {}
    }
}