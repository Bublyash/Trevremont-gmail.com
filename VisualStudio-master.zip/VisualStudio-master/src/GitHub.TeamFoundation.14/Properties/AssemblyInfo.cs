﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.TeamFoundation.14")]
[assembly: AssemblyDescription("GitHub TeamFoundation")]
[assembly: Guid("b389adaf-62cc-486e-85b4-2d8b078df763")]
