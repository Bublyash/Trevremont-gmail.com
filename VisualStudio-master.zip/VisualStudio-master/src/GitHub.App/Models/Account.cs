﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Reactive.Linq;
using System.Windows.Media.Imaging;
using NullGuard;
using ReactiveUI;

namespace GitHub.Models
{
    [DebuggerDisplay("{DebuggerDisplay,nq}")]
    public class Account : ReactiveObject, IAccount
    {
        BitmapSource avatar;

        public Account(
            string login,
            bool isUser,
            bool isEnterprise,
            int ownedPrivateRepositoryCount,
            long privateRepositoryInPlanCount,
            IObservable<BitmapSource> bitmapSource)
        {
            Login = login;
            IsUser = isUser;
            IsEnterprise = isEnterprise;
            OwnedPrivateRepos = ownedPrivateRepositoryCount;
            PrivateReposInPlan = privateRepositoryInPlanCount;
            IsOnFreePlan = privateRepositoryInPlanCount == 0;
            HasMaximumPrivateRepositories = OwnedPrivateRepos >= PrivateReposInPlan;

            bitmapSource.ObserveOn(RxApp.MainThreadScheduler)
                .Subscribe(x => avatar = x);
        }

        public bool IsOnFreePlan { get; private set; }

        public bool HasMaximumPrivateRepositories { get; private set; }

        public bool IsUser { get; private set; }

        public bool IsEnterprise { get; private set; }

        public string Login { get; private set; }

        public int OwnedPrivateRepos { get; private set; }

        public long PrivateReposInPlan { get; private set; }

        [AllowNull]
        public BitmapSource Avatar
        {
            [return: AllowNull]
            get { return avatar; }
            set { avatar = value; this.RaisePropertyChanged(); }
        }

#region Equality things
        public void CopyFrom(IAccount other)
        {
            if (!Equals(other))
                throw new ArgumentException("Instance to copy from doesn't match this instance. this:(" + this + ") other:(" + other + ")", nameof(other));
            OwnedPrivateRepos = other.OwnedPrivateRepos;
            PrivateReposInPlan = other.PrivateReposInPlan;
            IsOnFreePlan = other.IsOnFreePlan;
            HasMaximumPrivateRepositories = other.HasMaximumPrivateRepositories;
            Avatar = other.Avatar;
        }

        public override bool Equals([AllowNull]object obj)
        {
            if (ReferenceEquals(this, obj))
                return true;
            var other = obj as Account;
            return other != null && Login == other.Login && IsUser == other.IsUser && IsEnterprise == other.IsEnterprise;
        }

        public override int GetHashCode()
        {
            return (Login?.GetHashCode() ?? 0) ^ IsUser .GetHashCode() ^ IsEnterprise.GetHashCode();
        }

        bool IEquatable<IAccount>.Equals([AllowNull]IAccount other)
        {
            if (ReferenceEquals(this, other))
                return true;
            return other != null && Login == other.Login && IsUser == other.IsUser && IsEnterprise == other.IsEnterprise;
        }

        public int CompareTo([AllowNull]IAccount other)
        {
            return other != null ? String.Compare(Login, other.Login, StringComparison.CurrentCulture) : 1;
        }

        public static bool operator >([AllowNull]Account lhs, [AllowNull]Account rhs)
        {
            if (ReferenceEquals(lhs, rhs))
                return false;
            return lhs?.CompareTo(rhs) > 0;
        }

        public static bool operator <([AllowNull]Account lhs, [AllowNull]Account rhs)
        {
            if (ReferenceEquals(lhs, rhs))
                return false;
            return (object)lhs == null || lhs.CompareTo(rhs) < 0;
        }

        public static bool operator ==([AllowNull]Account lhs, [AllowNull]Account rhs)
        {
            return Equals(lhs, rhs) && ((object)lhs == null || lhs.CompareTo(rhs) == 0);
        }

        public static bool operator !=([AllowNull]Account lhs, [AllowNull]Account rhs)
        {
            return !(lhs == rhs);
        }
        #endregion

        [return: AllowNull]
        public override string ToString()
        {
            return Login;
        }

        internal string DebuggerDisplay
        {
            get
            {
                return String.Format(CultureInfo.InvariantCulture,
                    "Account: Login: {0} IsUser: {1}", Login, IsUser);
            }
        }
    }
}
