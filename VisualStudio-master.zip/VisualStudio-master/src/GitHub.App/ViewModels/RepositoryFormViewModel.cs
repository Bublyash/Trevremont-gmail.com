﻿using System;
using System.Reactive.Linq;
using System.Text.RegularExpressions;
using System.Windows.Input;
using GitHub.Models;
using GitHub.Validation;
using NullGuard;
using ReactiveUI;

namespace GitHub.ViewModels
{
    /// <summary>
    /// Base class for the Repository publish/create dialogs. It represents the details about the repository itself.
    /// </summary>
    public abstract class RepositoryFormViewModel : BaseViewModel
    {
        readonly ObservableAsPropertyHelper<string> safeRepositoryName;

        protected RepositoryFormViewModel()
        {
            CanKeepPrivateObservable = this.WhenAny(
                x => x.SelectedAccount.IsEnterprise,
                x => x.SelectedAccount.IsOnFreePlan,
                x => x.SelectedAccount.HasMaximumPrivateRepositories,
                (isEnterprise, isOnFreePlan, hasMaxPrivateRepos) =>
                isEnterprise.Value || (!isOnFreePlan.Value && !hasMaxPrivateRepos.Value));

            CanKeepPrivateObservable
                .Where(x => !x)
                .Subscribe(x => KeepPrivate = false);

            safeRepositoryName = this.WhenAny(x => x.RepositoryName, x => x.Value)
                .Select(x => x != null ? GetSafeRepositoryName(x) : null)
                .ToProperty(this, x => x.SafeRepositoryName);
        }

        string description;
        /// <summary>
        /// Description to set on the repo (optional)
        /// </summary>
        [AllowNull]
        public string Description
        {
            [return: AllowNull]
            get { return description; }
            set { this.RaiseAndSetIfChanged(ref description, value); }
        }

        bool keepPrivate;
        /// <summary>
        /// Make the new repository private
        /// </summary>
        public bool KeepPrivate
        {
            get { return keepPrivate; }
            set { this.RaiseAndSetIfChanged(ref keepPrivate, value); }
        }

        string repositoryName;
        /// <summary>
        /// Name of the repository as typed by user
        /// </summary>
        [AllowNull]
        public string RepositoryName
        {
            [return: AllowNull]
            get { return repositoryName; }
            set { this.RaiseAndSetIfChanged(ref repositoryName, value); }
        }

        public ReactivePropertyValidator<string> RepositoryNameValidator { get; protected set; }

        /// <summary>
        /// Name of the repository after fixing it to be safe (dashes instead of spaces, etc)
        /// </summary>
        public string SafeRepositoryName
        {
            [return: AllowNull]
            get { return safeRepositoryName.Value; }
        }

        public ReactivePropertyValidator<string> SafeRepositoryNameWarningValidator { get; protected set; }

        IAccount selectedAccount;
        /// <summary>
        /// Account where the repository is going to be created on
        /// </summary>
        [AllowNull]
        public IAccount SelectedAccount
        {
            [return: AllowNull]
            get { return selectedAccount; }
            set { this.RaiseAndSetIfChanged(ref selectedAccount, value); }
        }

        public bool ShowUpgradePlanWarning { get; private set; }

        public bool ShowUpgradeToMicroPlanWarning { get; private set; }

        public ICommand UpgradeAccountPlan { get; private set; }

        protected IObservable<bool> CanKeepPrivateObservable { get; private set; }

        // These are the characters which are permitted when creating a repository name on GitHub The Website
        static readonly Regex invalidRepositoryCharsRegex = new Regex(@"[^0-9A-Za-z_\.\-]", RegexOptions.ECMAScript);

        /// <summary>
        /// Given a repository name, returns a safe version with invalid characters replaced with dashes.
        /// </summary>
        protected static string GetSafeRepositoryName(string name)
        {
            return invalidRepositoryCharsRegex.Replace(name, "-");
        }

        protected virtual Octokit.NewRepository GatherRepositoryInfo()
        {
            return new Octokit.NewRepository(RepositoryName)
            {
                Description = Description,
                Private = KeepPrivate
            };
        }
    }
}
