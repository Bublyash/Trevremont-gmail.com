﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.App")]
[assembly: AssemblyDescription("Provides the view models for the GitHub for Visual Studio extension")]
[assembly: Guid("a8b9a236-d238-4733-b116-716872a1e8e0")]
