﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.UI.Recative")]
[assembly: AssemblyDescription("GitHub flavored WPF styles and controls that require Rx and RxUI")]
[assembly: Guid("885a491c-1d13-49e7-baa6-d61f424befcb")]
