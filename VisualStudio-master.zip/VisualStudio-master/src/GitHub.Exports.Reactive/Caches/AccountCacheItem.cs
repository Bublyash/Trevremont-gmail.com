﻿using System;
using GitHub.Models;
using GitHub.Primitives;
using Octokit;

namespace GitHub.Caches
{
    public class AccountCacheItem : IAvatarContainer
    {
        public static AccountCacheItem Create(Account apiAccount)
        {
            return new AccountCacheItem(apiAccount);
        }

        public static AccountCacheItem Create(UserAndScopes userAndScopes)
        {
            return new AccountCacheItem(userAndScopes.User);
        }

        public AccountCacheItem()
        { }

        public AccountCacheItem(Account account)
        {
            Login = account.Login;
            OwnedPrivateRepositoriesCount = account.OwnedPrivateRepos;
            PrivateRepositoriesInPlanCount = (account.Plan == null ? 0 : account.Plan.PrivateRepos);
            IsUser = (account as User) != null;
            Uri htmlUrl;
            IsEnterprise = Uri.TryCreate(account.HtmlUrl, UriKind.Absolute, out htmlUrl)
                && !HostAddress.IsGitHubDotComUri(htmlUrl);
            PrivateRepositoriesInPlanCount = account.Plan != null ? account.Plan.PrivateRepos : 0;
            OwnedPrivateRepositoriesCount = account.OwnedPrivateRepos;
            AvatarUrl = account.AvatarUrl;
        }

        public string Login { get; set; }
        public bool IsUser { get; set; }
        public bool IsEnterprise { get; set; }
        public int OwnedPrivateRepositoriesCount { get; set; }
        public long PrivateRepositoriesInPlanCount { get; set; }
        public string AvatarUrl { get; set; }
    }
}
