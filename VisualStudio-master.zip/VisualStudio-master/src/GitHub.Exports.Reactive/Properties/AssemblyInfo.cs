﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Exports.Reactive")]
[assembly: AssemblyDescription("GitHub interfaces for mef exports with reactive dependencies")]
[assembly: Guid("e4ed0537-d1d9-44b6-9212-3096d7c3f7a1")]
