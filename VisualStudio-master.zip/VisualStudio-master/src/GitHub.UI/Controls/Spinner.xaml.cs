﻿using System.Windows.Controls;

namespace GitHub.UI.Controls
{
    public partial class Spinner : UserControl
    {
        public Spinner()
        {
            InitializeComponent();
        }
    }
}
