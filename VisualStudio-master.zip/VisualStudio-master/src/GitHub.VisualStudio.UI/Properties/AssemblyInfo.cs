﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.VisualStudio.UI")]
[assembly: AssemblyDescription("GitHub.VisualStudio.UI")]
[assembly: Guid("d1dfbb0c-b570-4302-8f1e-2e3a19c41961")]
