﻿namespace GitHub.VisualStudio.UI
{
    public enum RepositoryOrigin
    {
        Unknown,
        DotCom,
        Enterprise,
        Other,
        NonGitRepository,
    }
}
