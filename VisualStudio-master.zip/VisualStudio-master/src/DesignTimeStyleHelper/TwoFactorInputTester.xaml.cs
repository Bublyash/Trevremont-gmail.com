﻿using System;
using System.Windows;

namespace DesignTimeStyleHelper
{
    /// <summary>
    /// Interaction logic for TwoFactorInputTester.xaml
    /// </summary>
    public partial class TwoFactorInputTester : Window
    {
        public TwoFactorInputTester()
        {
            InitializeComponent();
        }
    }
}
