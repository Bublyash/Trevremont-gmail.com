using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("GitHub Extension for Visual Studio")]
[assembly: AssemblyVersion("1.99.0.1")]
[assembly: AssemblyFileVersion("1.99.0.1")]
[assembly: ComVisible(false)]
[assembly: AssemblyCompany("GitHub, Inc.")]
[assembly: AssemblyCopyright("Copyright � GitHub, Inc. 2014-2016")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en-US")]

namespace System
{
    internal static class AssemblyVersionInformation {
        internal const string Version = "1.99.0.1";
    }
}
