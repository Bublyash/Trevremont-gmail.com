﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Extensions")]
[assembly: AssemblyDescription("Provides useful extension and utility methods common to the needs of GitHub applications")]
[assembly: Guid("3bf91177-3d16-425d-9c62-50a86cf26298")]
