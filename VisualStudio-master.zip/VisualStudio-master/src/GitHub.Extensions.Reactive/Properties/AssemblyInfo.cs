﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Extensions.Reactive")]
[assembly: AssemblyDescription("Provides useful Rx based extension and utility methods common to the needs of GitHub applications")]
[assembly: Guid("73e49b11-0bd0-4984-b9a8-3e7edceb071e")]
