﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.CredentialManagement")]
[assembly: AssemblyDescription("GitHub CredentialManagement")]
[assembly: Guid("41a47c5b-c606-45b4-b83c-22b9239e4da0")]
