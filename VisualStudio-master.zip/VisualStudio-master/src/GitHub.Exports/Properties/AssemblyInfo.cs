﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GitHub.Exports")]
[assembly: AssemblyDescription("GitHub interfaces for mef exports")]
[assembly: Guid("9aea02db-02b5-409c-b0ca-115d05331a6b")]
