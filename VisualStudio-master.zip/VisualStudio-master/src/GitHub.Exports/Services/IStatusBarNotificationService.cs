﻿namespace GitHub.Services
{
    // for mef purposes
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1040:AvoidEmptyInterfaces")]
    public interface IStatusBarNotificationService : INotificationService
    {
    }
}
