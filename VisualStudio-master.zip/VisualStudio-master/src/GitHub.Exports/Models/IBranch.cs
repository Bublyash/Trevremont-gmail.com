﻿namespace GitHub.Models
{
    public interface IBranch
    {
        string Name { get; }
    }
}
