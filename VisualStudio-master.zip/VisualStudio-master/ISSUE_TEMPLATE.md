Hello! Please read the contributing guidelines before submitting an issue.

- GitHub Extension version:
- Visual Studio version:

__What happened__ (with steps, logs and screenshots, if possible)
